# P0-12 Legacy 資料完整提取分析報告

**建立日期**：2026-01-12  
**目的**：徹底分析舊資料夾中還有多少等待提取的資料  
**文件狀態**：WORKING DOCUMENT（不鎖定，可回滾）

---

## 一、執行摘要

### 1.1 整體提取完成度

**設計階段完成度**：約 **30-40%**  
**實作階段完成度**：約 **15-20%**

### 1.2 關鍵發現

1. **題庫主題**：10 個主題，僅 1 個完成完整整合（chronic_depletion）
2. **題目藍圖主題**：10 個主題，與題庫有重疊但也有獨有主題
3. **domain/ 資料夾已有部分檔案**：questions 和 scoring 已有 9-10 個主題，但 narratives、recommendations、riskchains 僅有 2 個主題
4. **ContentDB 檔案**：11 個 ContentDB_*.js 檔案，包含大量敘事和建議內容
5. **guidanceActionTemplates**：包含大量行動建議模板，尚未提取

---

## 二、Legacy 資料來源盤點

### 2.1 題庫資料（questionBank.v1.json）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/questionBank.v1.json`

**主題清單**（10 個主題）：

| 主題 ID | 中文標籤 | 題數 | 提取狀態 | 整合狀態 |
|---------|---------|------|---------|---------|
| `chronic_depletion` | 長期耗竭 | 7 | ✅ 已提取 | ✅ 已整合（設計完成，檔案已寫入） |
| `hyper_responsibility` | 過度責任 | 5-7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `fear_based_stability` | 恐懼驅動的穩定 | 3-7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `loss_of_agency` | 主控感流失 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `social_comparison` | 社會比較壓力 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `suppressed_needs` | 需求壓抑 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `identity_diffusion` | 自我模糊 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `emotional_permeability` | 情緒滲透 | 7 | ❌ 未提取 | ❌ 未整合 |
| `avoidance_coping` | 逃避型因應 | 7 | ❌ 未提取 | ❌ 未整合 |
| 重複的 `hyper_responsibility` | 過度責任 | 7 | ⚠️ 部分提取 | ❌ 未整合 |

**提取完成度**：
- Questions：9 / 10 = **90%**（已有檔案）
- Scoring：10 / 10 = **100%**（已有檔案）
- Narratives：2 / 10 = **20%**（僅 chronic_depletion 和 stress_recovery）
- Recommendations：2 / 10 = **20%**（僅 chronic_depletion 和 stress_recovery）
- Riskchains：2 / 10 = **20%**（僅 chronic_depletion 和 stress_recovery）

**完整整合完成度**：1 / 10 = **10%**（僅 chronic_depletion 完成完整整合）

---

### 2.2 題目藍圖（p1_question_blueprint_v1.json）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/reports/p1_question_blueprint_v1.json`

**主題清單**（10 個主題）：

| 主題 ID | 中文標籤 | 題數 | 提取狀態 | 整合狀態 |
|---------|---------|------|---------|---------|
| `chronic_depletion` | 長期耗竭 | 7 | ✅ 已提取 | ✅ 已整合 |
| `loss_of_agency` | 主控感流失 | 7 | ⚠️ 部分提取 | ❌ 未整合 |
| `hyper_responsibility` | 過度責任 | 7 | ⚠️ 部分提取 | ❌ 未整合 |
| `fear_based_stability` | 恐懼驅動的穩定 | 7 | ⚠️ 部分提取 | ❌ 未整合 |
| `identity_diffusion` | 自我模糊 | 7 | ⚠️ 部分提取 | ❌ 未整合 |
| `suppressed_needs` | 需求壓抑 | 7 | ⚠️ 部分提取 | ❌ 未整合 |
| `chronic_alertness` | 長期警戒 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `unprocessed_loss` | 未處理的失落 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `meaning_vacuum` | 意義真空 | 7 | ⚠️ 部分提取 | ❌ 未整合（questions 和 scoring 有，但 narratives/reco/risk 無） |
| `self_erosion` | 自我耗損 | 7 | ⚠️ 部分提取 | ❌ 未整合（scoring 有，但 questions/narratives/reco/risk 無） |

**提取完成度**：
- Questions：9 / 10 = **90%**（缺少 self_erosion）
- Scoring：10 / 10 = **100%**（全部都有）
- Narratives：2 / 10 = **20%**
- Recommendations：2 / 10 = **20%**
- Riskchains：2 / 10 = **20%**

**完整整合完成度**：1 / 10 = **10%**

---

### 2.3 Mother Themes 定義（motherThemes.v1.json）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/ontology/motherThemes.v1.json`

**主題清單**（10 個主題）：

1. `chronic_depletion` - 長期耗竭
2. `loss_of_agency` - 主控感流失
3. `hyper_responsibility` - 過度承擔
4. `fear_based_stability` - 恐懼型求穩
5. `identity_diffusion` - 自我模糊
6. `suppressed_needs` - 需求壓抑
7. `chronic_alertness` - 長期警戒
8. `unprocessed_loss` - 未處理的失落
9. `meaning_vacuum` - 意義真空
10. `self_erosion` - 自我耗損

**狀態**：✅ 已定義，但尚未提取為 Facet manifest

---

### 2.4 計分系統（scorer.js）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/psych/scorer.js`

**狀態**：
- ✅ 邏輯已分析（在階段一設計規格中）
- ❌ 尚未轉換為 Python 模組
- ❌ 尚未整合到系統

**提取完成度**：設計 100%，實作 0%

---

### 2.5 結果模板（resultTemplates）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/core-content/resultTemplates/`

**檔案清單**（5 個檔案）：

| 檔案名稱 | 狀態 | 提取狀態 |
|---------|------|---------|
| `intervention_boundary_matrix.v1.json` | ✅ 已提取 | ✅ 已分析（Phase 2-1） |
| `anchor_statements.v1.json` | ✅ 已提取 | ✅ 已分析（Phase 2-1） |
| `five_element_mapping.v1.json` | ✅ 已提取 | ✅ 已分析（Phase 2-1） |
| `attribution_error_matrix.v1.json` | ✅ 已提取 | ✅ 已分析（Phase 2-1） |
| `consequence_chain_library.v1.json` | ✅ 已提取 | ✅ 已分析（Phase 2-1） |

**提取完成度**：✅ **100%**（已提取和分析）

---

### 2.6 結果生成邏輯

#### 2.6.1 buildGuidance.js

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/guidance/buildGuidance.js`

**狀態**：
- ✅ 決策邏輯已提取（10 條規則，Phase 2-4）
- ❌ 規則文件尚未寫入系統

**提取完成度**：設計 100%，檔案產出 0%

---

#### 2.6.2 guidancePrinciples.v1.json

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/ontology/guidancePrinciples.v1.json`

**狀態**：
- ✅ 原則已提取（40 條原則，轉換為 10 條規則，Phase 2-4）
- ❌ 規則文件尚未寫入系統

**提取完成度**：設計 100%，檔案產出 0%

---

#### 2.6.3 guidanceActionTemplates.v1.json

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/ontology/guidanceActionTemplates.v1.json`

**狀態**：
- ❌ **尚未提取**
- 包含大量行動建議模板（按母題和年齡帶分類）
- 用於生成具體的行動建議

**提取完成度**：**0%**

**內容**：
- 按母題（mother theme）分類
- 按年齡帶（age band）分類
- 包含具體的行動建議模板

**重要性**：🟡 **高**（用於生成 recommendations）

---

#### 2.6.4 intervention_boundary_matrix.v1.json

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/core-content/resultTemplates/intervention_boundary_matrix.v1.json`

**狀態**：
- ✅ 規則已提取（3 條規則，Phase 2-4）
- ❌ 規則文件尚未寫入系統

**提取完成度**：設計 100%，檔案產出 0%

---

### 2.7 ContentDB 檔案（ContentDB_*.js）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/core-content/`

**檔案清單**（11 個檔案）：

| 檔案名稱 | 內容類型 | 提取狀態 | 整合狀態 |
|---------|---------|---------|---------|
| `ContentDB_career.js` | 職業相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_family.js` | 家庭相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_finance.js` | 財務相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_health.js` | 健康相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_love.js` | 愛情相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_money.js` | 金錢相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_relationship.js` | 關係相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_self.js` | 自我相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_social.js` | 社交相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_study.js` | 學習相關敘事和建議 | ❌ 未提取 | ❌ 未整合 |
| `ContentDB_index.js` | 索引檔案 | ✅ 已查看 | - |

**內容結構**：
- 每個檔案包含 `ROUND2` 和 `ROUND3` 內容
- `ROUND2`：可能包含敘事內容
- `ROUND3`：可能包含建議內容

**提取完成度**：**0%**

**重要性**：🟡 **中高**（可能包含大量敘事和建議內容，但需要確認是否與主題相關）

---

### 2.8 其他可能的資料來源

#### 2.8.1 round2Situations.v1.json

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/round2Situations.v1.json`

**狀態**：❌ **尚未檢查**

**可能內容**：第二輪情境相關資料

---

#### 2.8.2 narrative 相關檔案

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/narrative/`

**檔案清單**：
- `elementNarrative.v1.js` - 元素敘事
- `hookRules.json` - Hook 規則
- `round2OracularText.v1.js` - 第二輪神諭文本

**狀態**：❌ **尚未提取**

**提取完成度**：**0%**

---

#### 2.8.3 guidance 相關檔案

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/guidance/`

**檔案清單**：
- `chains.json` - 鏈條定義
- `interventions.json` - 介入定義
- `modifiers.json` - 修飾符定義
- `schema.json` - Schema 定義

**狀態**：❌ **尚未提取**

**提取完成度**：**0%**

---

## 三、domain/ 資料夾現狀分析

### 3.1 已存在的檔案

#### 3.1.1 Questions（題庫）

**位置**：`domain/questions/`

**檔案清單**（9 個檔案）：
1. ✅ `chronic_alertness.questions.v1.0.json`
2. ✅ `chronic_depletion.questions.v1.0.json`
3. ✅ `fear_based_stability.questions.v1.0.json`
4. ✅ `hyper_responsibility.questions.v1.0.json`
5. ✅ `identity_diffusion.questions.v1.0.json`
6. ✅ `loss_of_agency.questions.v1.0.json`
7. ✅ `meaning_vacuum.questions.v1.0.json`
8. ✅ `stress_recovery.questions.v1.0.json`（現有系統原有）
9. ✅ `suppressed_needs.questions.v1.0.json`

**缺少的主題**：
- ❌ `emotional_permeability`（情緒滲透）- Legacy 題庫中有，但 domain/ 中沒有
- ❌ `avoidance_coping`（逃避型因應）- Legacy 題庫中有，但 domain/ 中沒有
- ❌ `unprocessed_loss`（未處理的失落）- 題目藍圖中有，但 domain/ 中沒有
- ❌ `self_erosion`（自我耗損）- 題目藍圖中有，但 domain/ 中沒有

**完成度**：9 / 13 = **69%**（假設需要 13 個主題）

**發現**：
- `emotional_permeability` 和 `avoidance_coping` 在 Legacy 題庫中存在（`packages/data/src/raw/legacy_questionBank.v1.json`）
- 但 domain/ 中沒有對應的 questions 和 scoring 檔案
- 需要從 Legacy 題庫中提取這兩個主題

---

#### 3.1.2 Scoring（計分）

**位置**：`domain/facets/`

**檔案清單**（10 個檔案）：
1. ✅ `chronic_alertness.scoring.v1.0.json`
2. ✅ `chronic_depletion.scoring.v1.0.json`
3. ✅ `fear_based_stability.scoring.v1.0.json`
4. ✅ `hyper_responsibility.scoring.v1.0.json`
5. ✅ `identity_diffusion.scoring.v1.0.json`
6. ✅ `loss_of_agency.scoring.v1.0.json`
7. ✅ `meaning_vacuum.scoring.v1.0.json`
8. ✅ `self_erosion.scoring.v1.0.json`
9. ✅ `stress_recovery.scoring.v1.0.json`（現有系統原有）
10. ✅ `suppressed_needs.scoring.v1.0.json`

**缺少的主題**：
- ❌ `emotional_permeability`（情緒滲透）- Legacy 題庫中有，但 domain/ 中沒有
- ❌ `avoidance_coping`（逃避型因應）- Legacy 題庫中有，但 domain/ 中沒有
- ❌ `unprocessed_loss`（未處理的失落）- 題目藍圖中有，但 domain/ 中沒有

**完成度**：10 / 13 = **77%**（假設需要 13 個主題）

**發現**：
- `self_erosion` 已有 scoring 檔案，但沒有 questions 檔案
- 需要從 Legacy 題庫或題目藍圖中提取 `self_erosion` 的 questions

---

#### 3.1.3 Narratives（敘事）

**位置**：`domain/narratives/`

**檔案清單**（2 個檔案）：
1. ✅ `chronic_depletion.narr.v1.0.json`（已整合）
2. ✅ `stress_recovery.narr.v1.0.json`（現有系統原有）

**缺少的主題**（8 個）：
- ❌ `chronic_alertness`
- ❌ `fear_based_stability`
- ❌ `hyper_responsibility`
- ❌ `identity_diffusion`
- ❌ `loss_of_agency`
- ❌ `meaning_vacuum`
- ❌ `self_erosion`
- ❌ `suppressed_needs`
- ❌ `emotional_permeability`
- ❌ `avoidance_coping`
- ❌ `unprocessed_loss`

**完成度**：2 / 13 = **15%**（假設需要 13 個主題）

---

#### 3.1.4 Recommendations（建議）

**位置**：`domain/recommendations/`

**檔案清單**（2 個檔案）：
1. ✅ `chronic_depletion.reco.v1.0.json`（已整合）
2. ✅ `stress_recovery.reco.v1.0.json`（現有系統原有）

**缺少的主題**（11 個）：同上 narratives

**完成度**：2 / 13 = **15%**

---

#### 3.1.5 Riskchains（風險鏈）

**位置**：`domain/riskchains/`

**檔案清單**（2 個檔案）：
1. ✅ `chronic_depletion.risk.v1.0.json`（已整合）
2. ✅ `stress_recovery.risk.v1.0.json`（現有系統原有）

**缺少的主題**（11 個）：同上 narratives

**完成度**：2 / 13 = **15%**

---

#### 3.1.6 Manifests（Facet 定義）

**位置**：`domain/manifests/`

**檔案清單**（1 個檔案）：
1. ✅ `stress_recovery.v1.0.json`（現有系統原有）

**缺少的主題**（12 個）：
- ❌ 所有 Legacy 主題的 manifest 都尚未建立

**完成度**：1 / 13 = **8%**

---

## 四、待提取資料完整清單

### 4.1 高優先級（必須提取）

#### 4.1.1 主題完整整合（9 個主題）

**需要整合的主題**（已有 questions 和 scoring，但缺少 narratives/recommendations/riskchains）：

1. **`hyper_responsibility`**（過度責任）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

2. **`fear_based_stability`**（恐懼驅動的穩定）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

3. **`loss_of_agency`**（主控感流失）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

4. **`social_comparison`**（社會比較壓力）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

5. **`suppressed_needs`**（需求壓抑）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

6. **`identity_diffusion`**（自我模糊）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

7. **`chronic_alertness`**（長期警戒）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

8. **`meaning_vacuum`**（意義真空）
   - ✅ Questions：已有
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

9. **`self_erosion`**（自我耗損）
   - ❌ Questions：待提取
   - ✅ Scoring：已有
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

**工作量**：9 個主題 × 每個主題需要 4 個檔案（narratives、recommendations、riskchains、manifest）= **36 個檔案**，加上 1 個 questions 檔案 = **37 個檔案**

---

#### 4.1.2 完全缺失的主題（3 個主題）

**需要完整建立的主題**：

1. **`emotional_permeability`**（情緒滲透）
   - ❌ Questions：待提取
   - ❌ Scoring：待提取
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

2. **`avoidance_coping`**（逃避型因應）
   - ❌ Questions：待提取
   - ❌ Scoring：待提取
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

3. **`unprocessed_loss`**（未處理的失落）
   - ❌ Questions：待提取
   - ❌ Scoring：待提取
   - ❌ Narratives：待提取
   - ❌ Recommendations：待提取
   - ❌ Riskchains：待提取
   - ❌ Manifest：待建立

**工作量**：3 個主題 × 每個主題需要 6 個檔案（questions、scoring、narratives、recommendations、riskchains、manifest）= **18 個檔案**

---

### 4.2 中優先級（建議提取）

#### 4.2.1 guidanceActionTemplates.v1.json

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/ontology/guidanceActionTemplates.v1.json`

**內容**：
- 行動建議模板（按母題和年齡帶分類）
- 用於生成具體的行動建議

**提取狀態**：❌ **尚未提取**

**重要性**：🟡 **高**（用於生成 recommendations）

**工作量**：中（需要分析結構並轉換為現有系統格式）

---

#### 4.2.2 ContentDB 檔案（11 個檔案）

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/core-content/ContentDB_*.js`

**內容**：
- 可能包含大量敘事和建議內容
- 按領域分類（career、family、finance、health、love、money、relationship、self、social、study）

**提取狀態**：❌ **尚未提取**

**重要性**：🟡 **中高**（需要確認是否與主題相關）

**工作量**：大（需要分析每個檔案，確認內容是否與主題相關）

---

#### 4.2.3 narrative 相關檔案

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/narrative/`

**檔案清單**：
- `elementNarrative.v1.js` - 元素敘事
- `hookRules.json` - Hook 規則
- `round2OracularText.v1.js` - 第二輪神諭文本

**提取狀態**：❌ **尚未提取**

**重要性**：🟡 **中**（可能包含敘事生成邏輯）

**工作量**：中（需要分析內容並確認是否與現有系統相關）

---

#### 4.2.4 guidance 相關檔案

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/src/core/guidance/`

**檔案清單**：
- `chains.json` - 鏈條定義
- `interventions.json` - 介入定義
- `modifiers.json` - 修飾符定義

**提取狀態**：❌ **尚未提取**

**重要性**：🟡 **中**（可能包含風險鏈生成邏輯）

**工作量**：中（需要分析內容並確認是否與現有系統相關）

---

### 4.3 低優先級（可選提取）

#### 4.3.1 round2Situations.v1.json

**位置**：`docs/legacy/115_1_3_my-first-app_failed/import/my-first-app/archive/legacy/round2Situations.v1.json`

**提取狀態**：❌ **尚未檢查**

**重要性**：🟢 **低**（需要確認內容是否與現有系統相關）

---

## 五、提取完成度統計

### 5.1 按資料類型統計

| 資料類型 | 總數 | 已提取 | 待提取 | 完成度 |
|---------|------|--------|--------|--------|
| **題庫主題** | 10 | 1 | 9 | 10% |
| **題目藍圖主題** | 10 | 1 | 9 | 10% |
| **Questions 檔案** | 13 | 9 | 4 | 69% |
| **Scoring 檔案** | 13 | 10 | 3 | 77% |
| **Narratives 檔案** | 13 | 2 | 11 | 15% |
| **Recommendations 檔案** | 13 | 2 | 11 | 15% |
| **Riskchains 檔案** | 13 | 2 | 11 | 15% |
| **Manifests 檔案** | 13 | 1 | 12 | 8% |
| **結果模板** | 5 | 5 | 0 | 100% |
| **結果生成邏輯** | 4 | 4 | 0 | 100%（設計） |
| **guidanceActionTemplates** | 1 | 0 | 1 | 0% |
| **ContentDB 檔案** | 11 | 0 | 11 | 0% |
| **narrative 相關檔案** | 3 | 0 | 3 | 0% |
| **guidance 相關檔案** | 3 | 0 | 3 | 0% |

### 5.2 按主題統計

| 主題 ID | Questions | Scoring | Narratives | Recommendations | Riskchains | Manifest | 完整度 |
|---------|-----------|---------|------------|----------------|------------|----------|--------|
| `chronic_depletion` | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | 83% |
| `stress_recovery` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | 100% |
| `hyper_responsibility` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `fear_based_stability` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `loss_of_agency` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `social_comparison` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `suppressed_needs` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `identity_diffusion` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `chronic_alertness` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `meaning_vacuum` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | 33% |
| `self_erosion` | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | 17% |
| `emotional_permeability` | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | 0% |
| `avoidance_coping` | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | 0% |
| `unprocessed_loss` | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | 0% |

**完整整合完成度**：1 / 13 = **8%**（僅 stress_recovery 完整，chronic_depletion 缺少 manifest）

---

## 六、待提取資料詳細清單

### 6.1 高優先級待提取（必須提取）

#### 6.1.1 主題完整整合（9 個主題 × 4 個檔案 = 36 個檔案）

**主題列表**：
1. `hyper_responsibility`
2. `fear_based_stability`
3. `loss_of_agency`
4. `social_comparison`
5. `suppressed_needs`
6. `identity_diffusion`
7. `chronic_alertness`
8. `meaning_vacuum`
9. `self_erosion`

**每個主題需要的檔案**：
- `domain/narratives/<theme_id>.narr.v1.0.json`
- `domain/recommendations/<theme_id>.reco.v1.0.json`
- `domain/riskchains/<theme_id>.risk.v1.0.json`
- `domain/manifests/<theme_id>.v1.0.json`

**總計**：36 個檔案

---

#### 6.1.2 完全缺失的主題（4 個主題）

**主題列表**：
1. `emotional_permeability`（情緒滲透）
   - Legacy 題庫中有，但 domain/ 中完全沒有
   - 需要：6 個檔案（questions、scoring、narratives、recommendations、riskchains、manifest）

2. `avoidance_coping`（逃避型因應）
   - Legacy 題庫中有，但 domain/ 中完全沒有
   - 需要：6 個檔案（questions、scoring、narratives、recommendations、riskchains、manifest）

3. `unprocessed_loss`（未處理的失落）
   - 題目藍圖中有，但 domain/ 中完全沒有
   - 需要：6 個檔案（questions、scoring、narratives、recommendations、riskchains、manifest）

4. `self_erosion`（自我耗損）
   - 題目藍圖中有，scoring 已有，但缺少其他檔案
   - 需要：5 個檔案（questions、narratives、recommendations、riskchains、manifest）

**每個主題需要的檔案**：
- `domain/questions/<theme_id>.questions.v1.0.json`
- `domain/facets/<theme_id>.scoring.v1.0.json`（self_erosion 已有）
- `domain/narratives/<theme_id>.narr.v1.0.json`
- `domain/recommendations/<theme_id>.reco.v1.0.json`
- `domain/riskchains/<theme_id>.risk.v1.0.json`
- `domain/manifests/<theme_id>.v1.0.json`

**總計**：23 個檔案（4 個主題 × 6 個檔案 - 1 個已存在的 scoring = 23 個檔案）

---

#### 6.1.3 chronic_depletion 的 Manifest

**檔案**：
- `domain/manifests/chronic_depletion.v1.0.json`

**總計**：1 個檔案

---

#### 6.1.4 階段一實際檔案整合

**內容**：
- Legacy 題目轉換為現有系統格式（10 個主題）
- Legacy 計分邏輯轉換為 Python 模組

**工作量**：大（需要轉換 10+ 個主題的題目和計分邏輯）

---

#### 6.1.5 Phase 2-4 規則文件產出

**內容**：
- 39 條規則文件
- 需要評估是否需要寫入系統

**檔案**（如需要）：
- `domain/knowledge_base/presentation_rules.v1.0.json`（或 Markdown）

**總計**：1 個檔案（如需要）

---

### 6.2 中優先級待提取（建議提取）

#### 6.2.1 guidanceActionTemplates.v1.json

**內容**：
- 行動建議模板（按母題和年齡帶分類）

**提取目標**：
- 分析結構
- 轉換為現有系統格式
- 整合到 recommendations 生成邏輯

**工作量**：中

---

#### 6.2.2 ContentDB 檔案（11 個檔案）

**內容**：
- 可能包含大量敘事和建議內容

**提取目標**：
- 分析每個檔案
- 確認內容是否與主題相關
- 如相關，提取並轉換

**工作量**：大（需要分析 11 個檔案）

---

#### 6.2.3 narrative 相關檔案（3 個檔案）

**內容**：
- 元素敘事、Hook 規則、第二輪神諭文本

**提取目標**：
- 分析內容
- 確認是否與現有系統相關
- 如相關，提取並轉換

**工作量**：中

---

#### 6.2.4 guidance 相關檔案（3 個檔案）

**內容**：
- 鏈條定義、介入定義、修飾符定義

**提取目標**：
- 分析內容
- 確認是否與現有系統相關
- 如相關，提取並轉換

**工作量**：中

---

### 6.3 低優先級待提取（可選）

#### 6.3.1 round2Situations.v1.json

**內容**：第二輪情境相關資料

**提取目標**：需要先檢查內容，確認是否與現有系統相關

**工作量**：小（需要先檢查）

---

## 七、提取工作量估算

### 7.1 高優先級工作量

| 任務 | 檔案數 | 工作量估算 | 優先級 |
|------|--------|-----------|--------|
| 主題完整整合（9 個主題） | 36 個檔案 | 大（每個主題可能需要數小時） | 🔴 極高 |
| 完全缺失的主題（3 個主題） | 18 個檔案 | 大（每個主題可能需要數小時） | 🔴 極高 |
| chronic_depletion Manifest | 1 個檔案 | 小（1-2 小時） | 🔴 極高 |
| 階段一實際檔案整合 | 10+ 個主題 | 大（需要轉換題目和計分邏輯） | 🟡 高 |
| Phase 2-4 規則文件產出 | 1 個檔案 | 小（1-2 小時，如需要） | 🟡 高 |

**高優先級總計**：約 **55+ 個檔案**，工作量：**大**

---

### 7.2 中優先級工作量

| 任務 | 檔案數 | 工作量估算 | 優先級 |
|------|--------|-----------|--------|
| guidanceActionTemplates | 1 個檔案 | 中（需要分析結構並轉換） | 🟡 中高 |
| ContentDB 檔案 | 11 個檔案 | 大（需要分析每個檔案） | 🟡 中 |
| narrative 相關檔案 | 3 個檔案 | 中（需要分析內容） | 🟡 中 |
| guidance 相關檔案 | 3 個檔案 | 中（需要分析內容） | 🟡 中 |

**中優先級總計**：約 **18 個檔案**，工作量：**大**

---

### 7.3 總工作量估算

**高優先級**：
- 檔案數：約 55+ 個檔案
- 工作量：大（可能需要數週時間）

**中優先級**：
- 檔案數：約 18 個檔案
- 工作量：大（可能需要數週時間）

**總計**：
- 檔案數：約 **73+ 個檔案**
- 工作量：**非常大**（可能需要數週到數月時間）

---

## 八、提取優先級建議

### 8.1 第一優先（立即執行）

1. **Phase 2-4 規則文件產出**（如需要）
   - 工作量：小（1-2 小時）
   - 優先級：🔴 極高
   - 狀態：設計已完成，只需產出檔案

2. **chronic_depletion Manifest 建立**
   - 工作量：小（1-2 小時）
   - 優先級：🔴 極高
   - 狀態：chronic_depletion 已整合，只需建立 manifest

---

### 8.2 第二優先（後續執行）

3. **主題完整整合（9 個主題）**
   - 工作量：大（每個主題可能需要數小時）
   - 優先級：🔴 極高
   - 狀態：已有 questions 和 scoring，只需提取 narratives、recommendations、riskchains

4. **完全缺失的主題（3 個主題）**
   - 工作量：大（每個主題可能需要數小時）
   - 優先級：🔴 極高
   - 狀態：需要完整建立

---

### 8.3 第三優先（可選執行）

5. **guidanceActionTemplates 提取**
   - 工作量：中
   - 優先級：🟡 中高
   - 狀態：可能對生成 recommendations 有幫助

6. **ContentDB 檔案分析**
   - 工作量：大
   - 優先級：🟡 中
   - 狀態：需要先確認內容是否與主題相關

7. **narrative 和 guidance 相關檔案分析**
   - 工作量：中
   - 優先級：🟡 中
   - 狀態：需要先確認內容是否與現有系統相關

---

## 九、關鍵發現

### 9.1 資料散落情況

1. **domain/ 資料夾已有部分檔案**：
   - Questions 和 Scoring 已有 9-10 個主題
   - 但 Narratives、Recommendations、Riskchains 僅有 2 個主題
   - 這表示之前可能已經做過部分提取，但沒有完成整合

2. **Legacy 資料夾結構複雜**：
   - 資料散落在多個位置（archive/legacy/、src/core/、reports/）
   - 需要系統性檢查每個資料夾

3. **ContentDB 檔案可能包含大量內容**：
   - 11 個 ContentDB_*.js 檔案
   - 可能包含大量敘事和建議內容
   - 需要分析確認是否與主題相關

### 9.2 整合完成度

**完整整合完成度**：約 **8%**（僅 stress_recovery 完整）

**部分整合完成度**：
- Questions：69%
- Scoring：77%
- Narratives：15%
- Recommendations：15%
- Riskchains：15%
- Manifests：8%

### 9.3 待提取資料總量

**高優先級**：約 **55+ 個檔案**
**中優先級**：約 **18 個檔案**
**總計**：約 **73+ 個檔案**

---

## 十、下一步建議

### 10.1 立即執行（第一優先）

1. **Phase 2-4 規則文件產出**（如需要）
   - 評估是否需要寫入系統
   - 如需要，確定寫入位置和格式
   - 執行寫入操作

2. **chronic_depletion Manifest 建立**
   - 建立 `domain/manifests/chronic_depletion.v1.0.json`
   - 完成 chronic_depletion 的完整整合

### 10.2 後續執行（第二優先）

3. **主題完整整合（9 個主題）**
   - 按照 Phase 2-2 的轉換規範，提取和轉換每個主題
   - 進行語境轉換（心理學 → 玄學）
   - 進行結構轉換（動態 → 靜態）
   - 生成符合現有系統格式的資料檔案

4. **完全缺失的主題（3 個主題）**
   - 從 Legacy 題庫中提取 questions
   - 建立 scoring 檔案
   - 按照 Phase 2-2 的轉換規範，提取和轉換 narratives、recommendations、riskchains
   - 建立 manifest 檔案

### 10.3 可選執行（第三優先）

5. **guidanceActionTemplates 提取**
   - 分析結構
   - 轉換為現有系統格式
   - 整合到 recommendations 生成邏輯

6. **ContentDB 檔案分析**
   - 分析每個檔案
   - 確認內容是否與主題相關
   - 如相關，提取並轉換

---

## 十一、總結

### 11.1 待提取資料總量

**高優先級**：
- 主題完整整合：36 個檔案（9 個主題 × 4 個檔案）
- 完全缺失的主題：23 個檔案（4 個主題，其中 1 個已有 scoring）
- chronic_depletion Manifest：1 個檔案
- Phase 2-4 規則文件：1 個檔案（如需要）
- **總計**：約 **61 個檔案**

**中優先級**：
- guidanceActionTemplates：1 個檔案
- ContentDB 檔案：11 個檔案（需要分析確認）
- narrative 相關檔案：3 個檔案（需要分析確認）
- guidance 相關檔案：3 個檔案（需要分析確認）
- **總計**：約 **18 個檔案**（需要先分析確認）

**總計**：約 **79 個檔案**

### 11.2 提取完成度

**整體提取完成度**：
- 設計階段：約 **30-40%**
- 實作階段：約 **15-20%**

**完整整合完成度**：約 **8%**（僅 stress_recovery 完整）

### 11.3 工作量估算

**高優先級工作量**：大（可能需要數週時間）
**中優先級工作量**：大（可能需要數週時間）
**總工作量**：非常大（可能需要數週到數月時間）

---

**文件狀態**：WORKING DOCUMENT（不鎖定，可回滾）  
**最後更新**：2026-01-12  
**下一步**：根據優先級建議執行提取工作
